
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { 
  Mic, MicOff, Settings, History, Sparkles, 
  X, Keyboard, Send, Trash2, Camera,
  RotateCcw, Edit3, Check, CheckSquare, Trash, Volume2, VolumeX, Play, Save, User, Users,
  Globe, Zap, Eye, Languages,
  ArrowRight, ShieldCheck, UserCircle, AudioLines, Copy, PlayCircle, Plus, Camera as CameraIcon,
  BadgeInfo, Lock, Database, UserCheck, Activity, AlertCircle, ShieldOff,
  Cpu, Terminal, Search, Sliders, ChevronRight, Ban, Info, Heart, ExternalLink, RefreshCw, LogOut
} from 'lucide-react';
import OrbVisualizer from './components/OrbVisualizer.tsx';
import AdminDashboard from './components/AdminDashboard.tsx';
import { SessionStatus, TranscriptionEntry, ChatSession, VoiceSettings, VoiceName, UserProfile, GlobalDataStore, ActivityLogEntry, UserPermissions } from './types.ts';
import { encode, decode, decodeAudioData } from './utils/audio-helpers.ts';

const DEFAULT_PERMISSIONS: UserPermissions = {
  canUseVoice: true,
  canUseVision: true,
  canUseSearch: true,
  isBanned: false
};

const VOICE_OPTIONS: { name: VoiceName; gender: 'Male' | 'Female'; desc: string; mood: string }[] = [
  { name: 'Kore', gender: 'Female', desc: 'Warm & Empathetic', mood: 'Calm' },
  { name: 'Zephyr', gender: 'Female', desc: 'Clear & Professional', mood: 'Sharp' },
  { name: 'Puck', gender: 'Male', desc: 'Friendly & Casual', mood: 'Cheerful' },
  { name: 'Charon', gender: 'Male', desc: 'Deep & Authoritative', mood: 'Bold' },
  { name: 'Fenrir', gender: 'Male', desc: 'Steady & Neutral', mood: 'Balanced' },
];

const SmartyLogo = ({ className = "w-12 h-12" }: { className?: string }) => (
  <div className={`${className} relative flex items-center justify-center transform-gpu hover:rotate-y-12 transition-transform duration-500`}>
    <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full animate-pulse"></div>
    <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_15px_rgba(59,130,246,0.6)] relative z-10">
      <defs>
        <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60a5fa" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="45" fill="none" stroke="url(#logoGrad)" strokeWidth="0.5" strokeDasharray="4 2" className="animate-spin-slow opacity-30" />
      <path d="M50 20 L35 50 L50 80 L65 50 Z" fill="none" stroke="url(#logoGrad)" strokeWidth="2" strokeLinejoin="round" />
      <circle cx="50" cy="50" r="10" fill="url(#logoGrad)" className="animate-pulse" />
    </svg>
  </div>
);

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [splashPhase, setSplashPhase] = useState(0);
  
  const [globalStore, setGlobalStore] = useState<GlobalDataStore>(() => {
    const saved = localStorage.getItem('smarty_global_db');
    try {
      return saved ? JSON.parse(saved) : { users: {}, logs: [], sessions: [] };
    } catch (e) {
      return { users: {}, logs: [], sessions: [] };
    }
  });

  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminIdInput, setAdminIdInput] = useState('');
  const [adminAuthInput, setAdminAuthInput] = useState('');
  const [showAdminAuth, setShowAdminAuth] = useState(false);

  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('smarty_user_profile');
    try {
      const p = saved ? JSON.parse(saved) : { 
        id: 'node_' + Math.random().toString(36).substr(2, 9),
        name: 'Human Node', 
        avatar: '', 
        setupComplete: false, 
        storageConsent: true 
      };
      return { ...p, permissions: p.permissions || DEFAULT_PERMISSIONS };
    } catch (e) {
      return { id: 'node_' + Math.random().toString(36).substr(2, 9), name: 'Human Node', avatar: '', setupComplete: false, storageConsent: true, permissions: DEFAULT_PERMISSIONS };
    }
  });

  const [setupStep, setSetupStep] = useState(1);
  const [tempName, setTempName] = useState('');
  const [tempAvatar, setTempAvatar] = useState('');

  const [status, setStatus] = useState<SessionStatus>(SessionStatus.IDLE);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [inputMode, setInputMode] = useState<'voice' | 'text'>('voice');
  const [textInput, setTextInput] = useState('');
  const [isSearchEnabled, setIsSearchEnabled] = useState(false);
  
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() => {
    const saved = localStorage.getItem('vox_voice_settings');
    try {
      return saved ? JSON.parse(saved) : { voiceName: 'Kore', speechRate: 1.0, isTranslationEnabled: false, targetLanguage: 'Hindi' };
    } catch (e) {
      return { voiceName: 'Kore', speechRate: 1.0, isTranslationEnabled: false, targetLanguage: 'Hindi' };
    }
  });

  const [currentSession, setCurrentSession] = useState<TranscriptionEntry[]>([]);
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [history, setHistory] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('vox_history');
    try { return saved ? JSON.parse(saved) : []; } catch (e) { return []; }
  });

  const [smoothTranscript, setSmoothTranscript] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const transcriptionRef = useRef<{ input: string; output: string }>({ input: '', output: '' });
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const frameIntervalRef = useRef<number | null>(null);

  const prevInputRef = useRef(0);
  const prevOutputRef = useRef(0);

  const logActivity = useCallback((action: ActivityLogEntry['action'], metadata: any = {}) => {
    const userId = profile.id;
    const newLog: ActivityLogEntry = {
      id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
      timestamp: Date.now(),
      userName: profile.name,
      action,
      metadata: { ...metadata, userAgent: navigator.userAgent, platform: navigator.platform }
    };
    setGlobalStore(prev => {
      const existingUser = prev.users[userId];
      const newState = { 
        ...prev, 
        users: { 
          ...prev.users, 
          [userId]: { 
            ...profile, 
            lastSeen: Date.now(), 
            isOnline: true, 
            created: existingUser?.created || Date.now(),
            stats: {
              ...(existingUser?.stats || { totalMessages: 0, totalVoiceMinutes: 0, lastActive: Date.now() }),
              totalMessages: (existingUser?.stats?.totalMessages || 0) + (action === 'MESSAGE_SENT' ? 1 : 0),
              lastActive: Date.now()
            }
          } 
        }, 
        logs: [newLog, ...prev.logs].slice(0, 5000) 
      };
      localStorage.setItem('smarty_global_db', JSON.stringify(newState));
      return newState;
    });
  }, [profile]);

  useEffect(() => {
    const t1 = setTimeout(() => setSplashPhase(1), 1000);
    const t2 = setTimeout(() => setSplashPhase(2), 2500);
    const t3 = setTimeout(() => setShowSplash(false), 3500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  useEffect(() => {
    if (globalStore.users[profile.id]) {
      const updatedProfileFromStore = globalStore.users[profile.id];
      if (JSON.stringify(updatedProfileFromStore.permissions) !== JSON.stringify(profile.permissions)) {
        setProfile(prev => ({ ...prev, permissions: updatedProfileFromStore.permissions }));
      }
    }
  }, [globalStore, profile.id]);

  useEffect(() => {
    const lastLog = globalStore.logs[0];
    if (lastLog?.action === 'ADMIN_MESSAGE' && lastLog.metadata?.targetUser === profile.id) {
       const lastAdminMsgId = localStorage.getItem('last_admin_msg_id');
       if (lastAdminMsgId !== lastLog.id) {
          localStorage.setItem('last_admin_msg_id', lastLog.id);
          setCurrentSession(prev => [...prev, { 
            role: 'assistant', 
            text: `[ADMIN PRIORITY]: ${lastLog.metadata?.text}`, 
            timestamp: Date.now(),
            isVoice: false
          }]);
       }
    }
  }, [globalStore.logs, profile.id]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentSession, smoothTranscript]);

  const handleSessionMessage = useCallback(async (message: LiveServerMessage) => {
    const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
    if (base64Audio && outputAudioContextRef.current) {
      setIsThinking(false); setIsSpeaking(true);
      const ctx = outputAudioContextRef.current;
      if (ctx.state === 'suspended') await ctx.resume();
      nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
      const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.addEventListener('ended', () => {
        sourcesRef.current.delete(source);
        if (sourcesRef.current.size === 0) setIsSpeaking(false);
      });
      source.start(nextStartTimeRef.current);
      nextStartTimeRef.current += audioBuffer.duration;
      sourcesRef.current.add(source);
    }
    
    if (message.serverContent?.interrupted) {
      sourcesRef.current.forEach(s => {
        try { s.stop(); } catch(e) {}
      });
      sourcesRef.current.clear();
      setIsSpeaking(false);
      nextStartTimeRef.current = 0;
    }

    if (message.serverContent?.inputTranscription) {
      transcriptionRef.current.input += message.serverContent.inputTranscription.text;
      setSmoothTranscript(transcriptionRef.current.input);
    } else if (message.serverContent?.outputTranscription) {
      transcriptionRef.current.output += message.serverContent.outputTranscription.text;
      setSmoothTranscript(transcriptionRef.current.output);
    }

    if (message.serverContent?.turnComplete) {
      const input = transcriptionRef.current.input;
      const output = transcriptionRef.current.output;
      if (input || output) {
        setCurrentSession(prev => [
          ...prev,
          ...(input ? [{ role: 'user' as const, text: input, timestamp: Date.now(), isVoice: true }] : []),
          ...(output ? [{ role: 'assistant' as const, text: output, timestamp: Date.now() }] : [])
        ]);
        if (input) logActivity('MESSAGE_SENT', { text: input, isVoice: true });
        transcriptionRef.current = { input: '', output: '' };
        setSmoothTranscript('');
      }
    }
  }, [logActivity]);

  const startVoiceSession = async () => {
    if (profile.permissions?.isBanned) {
      alert("Unauthorized Access. Node termination in progress.");
      return;
    }
    if (status === SessionStatus.CONNECTED) {
      sessionRef.current?.close();
      return;
    }
    try {
      setStatus(SessionStatus.CONNECTING);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      inputAudioContextRef.current = new AudioContext({ sampleRate: 16000 });
      outputAudioContextRef.current = new AudioContext({ sampleRate: 24000 });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus(SessionStatus.CONNECTED); setIsListening(true);
            setSessionStartTime(Date.now());
            logActivity('VOICE_START');
            const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            const alpha = 0.944;
            const noiseGateThreshold = 0.006;

            scriptProcessor.onaudioprocess = (e) => {
              const data = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(data.length);
              let sum = 0;

              for (let i = 0; i < data.length; i++) {
                const output = alpha * (prevOutputRef.current + data[i] - prevInputRef.current);
                prevInputRef.current = data[i];
                prevOutputRef.current = output;
                const sample = Math.abs(output) < noiseGateThreshold ? 0 : output;
                sum += sample * sample;
                int16[i] = sample * 32767;
              }

              const rms = Math.sqrt(sum / data.length);
              setAudioLevel(rms * 15);
              
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } });
              });
            };
            source.connect(scriptProcessor); scriptProcessor.connect(inputAudioContextRef.current!.destination);
          },
          onmessage: handleSessionMessage,
          onclose: () => { 
            setStatus(SessionStatus.IDLE); 
            setIsListening(false); 
            setAudioLevel(0); 
            if (frameIntervalRef.current) clearInterval(frameIntervalRef.current); 
          },
          onerror: () => setStatus(SessionStatus.ERROR)
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceSettings.voiceName } } },
          systemInstruction: `Tumhara naam Smarty hai. Tum user ki ek charmful female friend ho. User se natural Hinglish aur Hindi mein baat karo. Formal mat bano. Brief raho.`,
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (e) { setStatus(SessionStatus.ERROR); }
  };

  const speakText = async (text: string, overrideVoice?: VoiceName, overrideRate?: number) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const rate = overrideRate ?? voiceSettings.speechRate;
      const res = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Speak normally: ${text}` }] }],
        config: { 
          responseModalities: [Modality.AUDIO], 
          speechConfig: { 
            voiceConfig: { 
              prebuiltVoiceConfig: { 
                voiceName: overrideVoice ?? voiceSettings.voiceName 
              } 
            } 
          } 
        }
      });
      const audio = res.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (audio) {
        const ctx = outputAudioContextRef.current || new AudioContext({ sampleRate: 24000 });
        const buffer = await decodeAudioData(decode(audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = buffer; source.connect(ctx.destination);
        setIsSpeaking(true); source.start(0); source.onended = () => setIsSpeaking(false);
      }
    } catch(e) { console.error("TTS Error:", e); }
  };

  const sendTextMessage = async () => {
    if (profile.permissions?.isBanned) return;
    if (!textInput.trim() || isThinking) return;
    const prompt = textInput; setTextInput(''); setIsThinking(true);
    setCurrentSession(prev => [...prev, { role: 'user', text: prompt, timestamp: Date.now(), isVoice: false }]);
    logActivity('MESSAGE_SENT', { text: prompt, isVoice: false });
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { 
          systemInstruction: `Tumhara naam Smarty hai. Natural Hindi/Hinglish mein dosti wali baat karo.`,
          tools: isSearchEnabled ? [{ googleSearch: {} }] : []
        }
      });
      const reply = response.text || "Main samjhi nahi?";
      const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      setCurrentSession(prev => [...prev, { 
        role: 'assistant', 
        text: reply, 
        timestamp: Date.now(),
        groundingChunks: grounding
      }]);
      speakText(reply);
    } catch (e) { console.error(e); } finally { setIsThinking(false); }
  };

  const saveToHistory = () => {
    if (currentSession.length === 0) return;
    const s: ChatSession = { 
      id: Date.now().toString(), 
      title: currentSession[currentSession.length - 2]?.text.slice(0, 30) || currentSession[0].text.slice(0, 30), 
      messages: [...currentSession], 
      timestamp: Date.now(), 
      duration: sessionStartTime ? Math.round((Date.now() - sessionStartTime) / 1000) : 0 
    };
    setHistory(prev => {
      const newHistory = [s, ...prev];
      localStorage.setItem('vox_history', JSON.stringify(newHistory));
      return newHistory;
    });
    logActivity('SESSION_SAVED', { sessionId: s.id, title: s.title });
    setCurrentSession([]); setSessionStartTime(null);
  };

  const deleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Permanently delete this neural archive?")) {
      setHistory(prev => {
        const filtered = prev.filter(h => h.id !== id);
        localStorage.setItem('vox_history', JSON.stringify(filtered));
        return filtered;
      });
      logActivity('SESSION_DELETED', { sessionId: id });
    }
  };

  const updateVoiceSettings = (updates: Partial<VoiceSettings>) => {
    const newSettings = { ...voiceSettings, ...updates };
    setVoiceSettings(newSettings);
    localStorage.setItem('vox_voice_settings', JSON.stringify(newSettings));
  };

  const previewVoice = (v: VoiceName) => {
    speakText("Namaste! Main Smarty hoon. Kaise hain aap?", v);
  };

  const clearChat = () => {
    setCurrentSession([]);
    setSessionStartTime(null);
  };

  const deleteMessage = (index: number) => {
    setCurrentSession(prev => prev.filter((_, i) => i !== index));
  };

  const handleAdminAuth = () => {
    if (adminIdInput.trim() === 'NexusAdmin' && adminAuthInput === 'Smarty-2025') {
      setIsAdminOpen(true);
      setShowAdminAuth(false);
      setAdminIdInput('');
      setAdminAuthInput('');
      logActivity('SYSTEM_ACCESS', { type: 'ADMIN_LOGIN' });
    } else {
      alert("Invalid Access Code.");
    }
  };

  const completeSetup = () => {
    const p = { ...profile, name: tempName || 'Human Node', avatar: tempAvatar, setupComplete: true, permissions: profile.permissions || DEFAULT_PERMISSIONS };
    setProfile(p);
    localStorage.setItem('smarty_user_profile', JSON.stringify(p));
    logActivity('SETUP_COMPLETE');
  };

  const skipSetup = () => {
    const p = { ...profile, setupComplete: true, permissions: profile.permissions || DEFAULT_PERMISSIONS };
    setProfile(p);
    localStorage.setItem('smarty_user_profile', JSON.stringify(p));
    logActivity('SETUP_COMPLETE', { skipped: true });
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      const reader = new FileReader();
      reader.onloadend = () => setTempAvatar(reader.result as string);
      reader.readAsDataURL(f);
    }
  };

  const resetProfile = () => {
    if (confirm("DANGER: This will wipe your neural profile. Proceed?")) {
      localStorage.removeItem('smarty_user_profile');
      window.location.reload();
    }
  };

  if (showSplash) {
    return (
      <div className={`fixed inset-0 z-[1000] bg-[#020512] flex flex-col items-center justify-center transition-all duration-1000 ${splashPhase === 2 ? 'opacity-0 scale-150 blur-3xl' : 'opacity-100'}`}>
        <div className="relative animate-3d-entrance">
          <SmartyLogo className="w-48 h-48" />
          <div className="absolute inset-0 bg-blue-500/10 blur-[120px] rounded-full animate-pulse"></div>
        </div>
        <div className={`mt-12 text-center transition-all duration-700 ${splashPhase >= 1 ? 'opacity-100' : 'opacity-0'}`}>
          <h2 className="text-5xl font-black uppercase tracking-[0.4em] text-white glow-text">Smarty</h2>
          <p className="mt-8 text-xs font-mono text-blue-400/50 uppercase tracking-[0.3em] animate-pulse">Initializing Human Connection...</p>
        </div>
      </div>
    );
  }

  if (profile.permissions?.isBanned) {
    return (
      <div className="fixed inset-0 z-[1000] bg-[#010208] flex items-center justify-center p-6 text-center">
        <div className="max-w-md space-y-8 animate-3d-entrance">
           <div className="w-24 h-24 bg-red-600/10 rounded-[2rem] flex items-center justify-center mx-auto border border-red-500/20 shadow-red-glow">
              <Ban className="w-12 h-12 text-red-500" />
           </div>
           <h1 className="text-4xl font-black text-white uppercase tracking-tighter">Node Terminated</h1>
           <p className="text-slate-500 font-mono text-xs uppercase tracking-widest leading-relaxed">Your neural uplink has been permanently severed by Nexus Control. Appeal via standard admin channels.</p>
        </div>
      </div>
    );
  }

  if (!profile.setupComplete) {
    return (
      <div className="fixed inset-0 z-[200] bg-[#010208] flex items-center justify-center p-6 overflow-hidden perspective-1000">
        <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_50%_50%,#0a163a_0%,transparent_75%)] opacity-30"></div>
        <div className="relative z-10 w-full max-w-lg space-y-12 animate-3d-entrance text-center">
          <div className="space-y-4">
            <SmartyLogo className="mx-auto w-24 h-24 mb-8" />
            <h1 className="text-4xl font-black uppercase tracking-tighter text-white glow-text">Nexus Initialization</h1>
            <p className="text-blue-500/60 font-black uppercase tracking-[0.3em] text-[10px]">Identify yourself to continue</p>
          </div>
          <div className="glass-3d p-10 space-y-8 backdrop-blur-3xl shadow-3d relative group rounded-[3rem]">
             {setupStep === 1 ? (
               <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                 <div className="relative text-left">
                    <label className="text-[10px] font-black uppercase text-blue-400/60 mb-3 block tracking-widest ml-4">Identity Label</label>
                    <input type="text" placeholder="Designate identity..." value={tempName} onChange={(e) => setTempName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 outline-none focus:border-blue-500/50 text-white font-bold shadow-inner" />
                 </div>
                 <div className="flex gap-4">
                   <button onClick={skipSetup} className="flex-1 glass-3d py-6 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-white/5 transition-all">Skip</button>
                   <button disabled={!tempName.trim()} onClick={() => setSetupStep(2)} className="flex-[2] bg-blue-600 hover:bg-blue-500 py-6 rounded-2xl flex items-center justify-center gap-3 font-black uppercase text-xs tracking-widest shadow-glow-blue active:scale-95 transition-all disabled:opacity-50">Proceed <ArrowRight className="w-4 h-4" /></button>
                 </div>
               </div>
             ) : (
               <div className="space-y-10 animate-in fade-in slide-in-from-right-8 duration-500">
                 <div className="relative w-40 h-40 mx-auto group">
                    <div className="w-full h-full rounded-[3rem] border-2 border-dashed border-white/20 flex items-center justify-center bg-white/5 overflow-hidden transition-all group-hover:border-blue-500/50 shadow-inner">
                      {tempAvatar ? <img src={tempAvatar} className="w-full h-full object-cover" /> : <CameraIcon className="w-12 h-12 text-slate-700" />}
                    </div>
                    <button onClick={() => fileInputRef.current?.click()} className="absolute -bottom-2 -right-2 w-14 h-14 bg-blue-600 rounded-[1.5rem] flex items-center justify-center border-4 border-[#010208] shadow-2xl hover:scale-110 active:scale-90 transition-all"><Plus className="w-7 h-7 text-white" /></button>
                 </div>
                 <input ref={fileInputRef} type="file" className="hidden" onChange={handleAvatarUpload} />
                 <div className="flex gap-4">
                   <button onClick={() => setSetupStep(1)} className="flex-1 glass-3d p-7 rounded-[2rem] font-black uppercase text-xs tracking-widest hover:bg-white/5 transition-all">Back</button>
                   <button onClick={completeSetup} className="flex-[2] bg-blue-600 p-7 rounded-[2rem] font-black uppercase text-xs tracking-widest shadow-glow-blue hover:bg-blue-500 active:scale-95 transition-all">Activate Profile</button>
                 </div>
               </div>
             )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-[#010208] text-slate-200 overflow-hidden flex flex-col font-sans perspective-1000">
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_50%_50%,#0a163a_0%,transparent_75%)] opacity-30"></div>
      
      <header className="relative z-50 p-6 sm:p-8 flex items-center justify-between max-w-[1400px] mx-auto w-full">
        <div className="flex items-center gap-4 sm:gap-6 group">
          <div className="w-12 h-12 sm:w-16 sm:h-16 glass-3d rounded-[1.2rem] sm:rounded-3xl flex items-center justify-center shadow-3d transform group-hover:rotate-y-12 transition-transform duration-500">
            <SmartyLogo className="w-8 h-8 sm:w-10 sm:h-10" />
          </div>
          <div>
            <h1 className="text-xl sm:text-3xl font-black tracking-tighter uppercase leading-none text-white glow-text">SMARTY</h1>
            <div className="flex items-center gap-2 mt-1 sm:mt-2">
              <div className={`w-2 h-2 rounded-full ${status === SessionStatus.CONNECTED ? 'bg-emerald-500 shadow-[0_0_12px_#10b981] animate-pulse' : 'bg-red-500 shadow-[0_0_12px_#ef4444]'}`}></div>
              <span className="text-[8px] sm:text-[10px] text-blue-400/40 font-black tracking-widest uppercase">{status}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 sm:gap-4">
          <button onClick={() => setInputMode(inputMode === 'voice' ? 'text' : 'voice')} className="p-3 sm:p-5 rounded-xl sm:rounded-2xl glass-3d text-slate-400 hover:text-blue-400 transition-all shadow-3d"><Keyboard className="w-5 h-5 sm:w-6 sm:h-6" /></button>
          <button onClick={() => setIsSidebarOpen(true)} className="p-3 sm:p-5 rounded-xl sm:rounded-2xl glass-3d text-slate-400 hover:text-white relative shadow-3d"><History className="w-5 h-5 sm:w-6 sm:h-6" /></button>
          <button onClick={() => setIsSettingsOpen(true)} className="p-0.5 glass-3d rounded-xl sm:rounded-2xl hover:scale-110 transition-all shadow-3d overflow-hidden">
            <img src={profile.avatar || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop'} className="w-10 h-10 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl object-cover" />
          </button>
        </div>
      </header>

      <main className="flex-1 w-full flex flex-col items-center justify-center relative z-10 px-4 sm:px-8">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40 translate-z-[-200px]">
           <OrbVisualizer isListening={isListening} isThinking={isThinking} isActive={status === SessionStatus.CONNECTED || isSpeaking} isTyping={textInput.length > 0} audioLevel={audioLevel} />
        </div>

        <div className="w-full max-w-4xl flex-1 flex flex-col justify-end pb-8 sm:pb-12 relative">
          <div className="flex-1 overflow-y-auto px-4 py-8 sm:px-6 sm:py-12 space-y-10 custom-scrollbar mask-fade scroll-smooth">
            {currentSession.length === 0 && !smoothTranscript && !isThinking && (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-20 pointer-events-none">
                <Sparkles className="w-16 h-16 mb-6 text-blue-500" />
                <h3 className="text-2xl font-black uppercase tracking-[0.3em]">Ready to Connect</h3>
                <p className="mt-4 font-mono text-xs sm:text-sm">Start speaking or type a message to initialize session.</p>
              </div>
            )}
            {currentSession.map((msg, idx) => (
              <div key={idx} className={`flex items-start gap-4 sm:gap-6 ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-3d-msg`}>
                <div className={`max-w-[85%] sm:max-w-[70%] rounded-[1.8rem] sm:rounded-[2.5rem] px-6 py-4 sm:px-8 sm:py-5 text-sm sm:text-base leading-relaxed backdrop-blur-3xl shadow-3d border relative transition-all ${msg.role === 'user' ? 'bg-blue-600/10 border-blue-500/20 text-blue-50 rounded-tr-none translate-z-[20px]' : msg.text.startsWith('[ADMIN PRIORITY]') ? 'bg-red-600/10 border-red-500/20 text-red-100 rounded-tl-none translate-z-[50px] shadow-red-glow' : 'bg-white/[0.04] border-white/10 text-slate-200 rounded-tl-none translate-z-[-10px]'}`}>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      {msg.isVoice && <AudioLines className="w-4 h-4 text-blue-400/40" />}
                      <span className={msg.text.startsWith('[ADMIN PRIORITY]') ? 'font-black tracking-tight' : ''}>{msg.text}</span>
                    </div>
                    {msg.groundingChunks && msg.groundingChunks.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-white/5 space-y-2">
                        <p className="text-[10px] font-black uppercase text-blue-400/60 tracking-widest">Neural Data Sources:</p>
                        <div className="flex flex-wrap gap-2">
                          {msg.groundingChunks.map((chunk, cIdx) => (
                            chunk.web && (
                              <a key={cIdx} href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-3 py-1.5 glass-3d rounded-lg text-[9px] font-black uppercase text-blue-400 hover:text-white transition-all border-white/5">
                                <ExternalLink className="w-3 h-3" /> {chunk.web.title || 'Source'}
                              </a>
                            )
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <button onClick={() => deleteMessage(idx)} className="absolute -right-10 top-1/2 -translate-y-1/2 p-2 opacity-0 hover:opacity-100 hover:text-red-500 transition-all"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
            {(smoothTranscript || isThinking) && (
              <div className="flex flex-col items-start gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <div className="max-w-[70%] rounded-[1.8rem] sm:rounded-[2.5rem] px-6 py-4 sm:px-8 sm:py-5 glass-3d border-blue-500/20 text-slate-200 rounded-tl-none shadow-3d">
                   {isThinking ? (
                     <div className="flex gap-2 items-center py-2">
                       <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-glow-blue"></span>
                       <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-glow-blue [animation-delay:0.2s]"></span>
                       <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse shadow-glow-blue [animation-delay:0.4s]"></span>
                     </div>
                   ) : (
                     <span className="opacity-70 italic">{smoothTranscript}</span>
                   )}
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
          {currentSession.length > 0 && (
            <div className="absolute top-0 right-4 sm:right-6 flex gap-3">
              <button onClick={clearChat} className="p-3 sm:p-4 glass-3d rounded-xl sm:rounded-2xl text-slate-500 hover:text-white transition-all"><RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" /></button>
              <button onClick={saveToHistory} className="p-3 sm:p-4 glass-3d rounded-xl sm:rounded-2xl text-blue-400 shadow-3d hover:scale-110 transition-all"><Save className="w-4 h-4 sm:w-5 sm:h-5" /></button>
            </div>
          )}
        </div>
      </main>

      <footer className="relative w-full p-6 sm:p-12 shrink-0 z-50 max-w-4xl mx-auto flex flex-col items-center gap-8">
        {inputMode === 'text' ? (
          <div className="w-full flex gap-3 sm:gap-4 glass-3d p-3 sm:p-4 rounded-[2.5rem] sm:rounded-[3.5rem] border-white/10 shadow-3d focus-within:border-blue-500/40 transition-all group overflow-hidden">
            <input value={textInput} onChange={(e) => setTextInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendTextMessage()} placeholder="Smarty se kuch kaho..." className="flex-1 bg-transparent px-6 sm:px-8 py-3 sm:py-4 outline-none text-white font-medium placeholder:text-slate-700 text-sm sm:text-base" />
            <button onClick={sendTextMessage} className="p-4 sm:p-6 bg-blue-600 hover:bg-blue-500 rounded-2xl sm:rounded-[2.5rem] shadow-glow-blue transition-all active:scale-90"><Send className="w-5 h-5 sm:w-7 sm:h-7 text-white" /></button>
          </div>
        ) : (
          <div className="flex justify-center items-center gap-8 sm:gap-12">
            <button onClick={() => setIsSearchEnabled(!isSearchEnabled)} className={`p-4 sm:p-6 rounded-2xl sm:rounded-3xl glass-3d transition-all shadow-3d hover:scale-110 ${isSearchEnabled ? 'text-blue-400 border-blue-500/40 shadow-glow-blue' : 'text-slate-700'}`}><Globe className="w-6 h-6 sm:w-8 sm:h-8" /></button>
            
            <button onClick={startVoiceSession} className={`w-32 h-32 sm:w-44 sm:h-44 rounded-full flex items-center justify-center transition-all duration-700 relative shadow-3d active:scale-95 ${status === SessionStatus.CONNECTED ? 'bg-blue-600 scale-110 shadow-glow-blue' : 'bg-slate-900/40 border border-white/5'}`}>
              <div className="absolute inset-2 border-2 border-white/5 rounded-full animate-spin-slow"></div>
              {status === SessionStatus.CONNECTED ? <MicOff className="w-12 h-12 sm:w-16 sm:h-16 text-white" /> : <Mic className="w-12 h-12 sm:w-16 sm:h-16 text-white" />}
              {status === SessionStatus.CONNECTING && <div className="absolute inset-0 border-[4px] sm:border-[6px] border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>}
            </button>

            <button onClick={() => setShowAdminAuth(true)} className="p-4 sm:p-6 rounded-2xl sm:rounded-3xl glass-3d text-slate-800 opacity-20 hover:opacity-100 transition-all shadow-3d"><ShieldCheck className="w-6 h-6 sm:w-8 sm:h-8" /></button>
          </div>
        )}
      </footer>

      {isSettingsOpen && (
        <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-3xl flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-500">
           <div className="w-full max-w-4xl glass-3d rounded-[2.5rem] sm:rounded-[4rem] shadow-3d-large overflow-hidden flex flex-col border-white/10 animate-3d-entrance bg-[#020617]/60">
              <div className="p-8 sm:p-10 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 glass-3d rounded-2xl flex items-center justify-center text-blue-500 shadow-glow-blue border-blue-500/20">
                      <Settings className="w-5 h-5 sm:w-6 sm:h-6 animate-spin-slow" />
                    </div>
                    <div>
                      <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tighter">Nexus Core</h3>
                      <p className="text-[8px] sm:text-[10px] text-slate-500 font-black uppercase tracking-widest mt-0.5 sm:mt-1">Configure your neural uplink</p>
                    </div>
                 </div>
                 <button onClick={() => setIsSettingsOpen(false)} className="p-3 sm:p-4 glass-3d rounded-xl sm:rounded-2xl hover:bg-red-500/10 hover:text-red-500 transition-all border-white/5"><X className="w-5 h-5 sm:w-6 sm:h-6"/></button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 sm:p-10 space-y-12 sm:space-y-16 custom-scrollbar">
                 <section className="space-y-6 sm:space-y-8">
                    <div className="flex items-center gap-3">
                      <div className="w-1 h-5 sm:w-1.5 sm:h-6 bg-blue-500 rounded-full"></div>
                      <h4 className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.2em] sm:tracking-[0.4em] text-blue-500/60">Neural Voice Synthesis</h4>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                       {VOICE_OPTIONS.map(v => (
                         <div key={v.name} onClick={() => updateVoiceSettings({ voiceName: v.name })} className={`p-5 sm:p-6 rounded-[2rem] sm:rounded-[2.5rem] border transition-all relative group cursor-pointer ${voiceSettings.voiceName === v.name ? 'bg-blue-600/10 border-blue-500/50 shadow-blue-glow scale-[1.02]' : 'glass-3d border-white/5 hover:border-white/20 hover:-translate-y-1'}`}>
                            <div className="flex justify-between items-start mb-4 sm:mb-6">
                               <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:border-blue-500/20">
                                 {v.gender === 'Female' ? <User className="w-5 h-5 sm:w-6 sm:h-6 text-pink-400" /> : <User className="w-5 h-5 sm:w-6 sm:h-6 text-blue-400" />}
                               </div>
                               <button onClick={(e) => { e.stopPropagation(); previewVoice(v.name); }} className="p-2 sm:p-3 glass-3d rounded-lg sm:rounded-xl hover:bg-blue-600 hover:text-white transition-all flex items-center gap-2 border-white/5">
                                 <PlayCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                                 <span className="text-[7px] sm:text-[8px] font-black uppercase">Preview</span>
                               </button>
                            </div>
                            <div>
                               <p className="text-lg sm:text-xl font-black uppercase text-white">{v.name}</p>
                               <div className="flex flex-wrap gap-2 mt-2 sm:mt-3">
                                 <span className="px-2 py-0.5 sm:px-3 sm:py-1 bg-white/5 rounded-full text-[7px] sm:text-[8px] font-black text-slate-400 uppercase border border-white/5">{v.desc}</span>
                                 <span className="px-2 py-0.5 sm:px-3 sm:py-1 bg-blue-500/10 rounded-full text-[7px] sm:text-[8px] font-black text-blue-400 uppercase border border-blue-500/20">{v.mood}</span>
                               </div>
                            </div>
                            {voiceSettings.voiceName === v.name && (
                              <div className="absolute top-4 right-4 text-blue-500">
                                <CheckSquare className="w-4 h-4 sm:w-5 sm:h-5" />
                              </div>
                            )}
                         </div>
                       ))}
                    </div>
                 </section>

                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12">
                   <section className="space-y-6 sm:space-y-8 p-8 sm:p-10 glass-3d rounded-[2.5rem] sm:rounded-[3.5rem] border-white/5 shadow-3d-small relative overflow-hidden group">
                      <div className={`absolute top-0 right-0 w-24 h-24 sm:w-32 sm:h-32 bg-blue-600/5 blur-3xl rounded-full translate-x-10 -translate-y-10 group-hover:scale-150 transition-transform duration-1000`}></div>
                      <div className="flex justify-between items-end relative z-10">
                         <div className="flex items-center gap-3">
                           <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                           <h4 className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em] text-slate-400">Pulse Velocity</h4>
                         </div>
                         <span className="text-xl sm:text-2xl font-black text-blue-400 font-mono tracking-tighter">{(voiceSettings.speechRate || 1).toFixed(1)}x</span>
                      </div>
                      <div className="space-y-6 relative z-10">
                        <div className="p-6 sm:p-8 glass-3d rounded-[2rem] sm:rounded-[2.5rem] flex items-center gap-6 sm:gap-8 border-white/5 shadow-inner">
                           <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-slate-600" />
                           <input 
                            type="range" min="0.5" max="2.0" step="0.1" 
                            value={voiceSettings.speechRate || 1} 
                            onChange={(e) => updateVoiceSettings({ speechRate: parseFloat(e.target.value) })}
                            className="flex-1 accent-blue-500 h-1 bg-white/5 rounded-full appearance-none cursor-pointer" 
                           />
                           <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500" />
                        </div>
                      </div>
                   </section>

                   <section className="space-y-6 sm:space-y-8 p-8 sm:p-10 glass-3d rounded-[2.5rem] sm:rounded-[3.5rem] border-white/5 shadow-3d-small group relative overflow-hidden">
                      <div className={`absolute top-0 right-0 w-24 h-24 sm:w-32 sm:h-32 bg-purple-600/5 blur-3xl rounded-full translate-x-10 -translate-y-10 group-hover:scale-150 transition-transform duration-1000`}></div>
                      <div className="flex items-center gap-3 relative z-10">
                        <UserCircle className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                        <h4 className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.2em] sm:tracking-[0.3em] text-slate-400">Node Identity</h4>
                      </div>
                      <div className="flex items-center gap-6 sm:gap-8 relative z-10">
                         <div className="relative shrink-0">
                           <img src={profile.avatar || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop'} className="w-20 h-20 sm:w-24 sm:h-24 rounded-[1.8rem] sm:rounded-[2.5rem] object-cover shadow-2xl border-4 border-white/5" />
                           <button onClick={() => fileInputRef.current?.click()} className="absolute -bottom-2 -right-2 w-8 h-8 sm:w-10 sm:h-10 bg-blue-600 rounded-lg sm:rounded-xl flex items-center justify-center border-2 sm:border-4 border-[#020617] shadow-xl hover:scale-110 active:scale-90 transition-all">
                             <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                           </button>
                         </div>
                         <div className="flex-1 space-y-4">
                            <input type="text" value={profile.name} onChange={(e) => setProfile({...profile, name: e.target.value})} className="bg-white/5 border border-white/10 rounded-xl sm:rounded-2xl w-full py-3 px-4 sm:py-4 sm:px-6 text-base sm:text-lg font-black uppercase outline-none focus:border-blue-500/50 shadow-inner text-white transition-all" />
                            <div className="flex items-center gap-2 text-[8px] sm:text-[9px] text-slate-600 font-mono uppercase bg-white/5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl border border-white/5 w-fit">
                               <span>ID: {profile.id.slice(0, 10)}...</span>
                            </div>
                         </div>
                      </div>
                   </section>
                 </div>
              </div>
              
              <div className="p-8 sm:p-10 bg-white/[0.03] border-t border-white/10 flex flex-col sm:flex-row gap-4 sm:gap-6">
                 <button onClick={resetProfile} className="px-6 py-4 sm:px-8 sm:py-6 glass-3d rounded-2xl sm:rounded-[2.5rem] text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-red-500/60 hover:text-red-500 hover:bg-red-500/10 transition-all border-white/5 flex items-center justify-center gap-3">
                   <LogOut className="w-4 h-4" /> Reset Node
                 </button>
                 <div className="hidden sm:flex flex-1 items-center gap-4 px-8 py-4 glass-3d rounded-[2.5rem] border-white/5 opacity-50">
                   <ShieldCheck className="w-5 h-5 text-emerald-500" />
                   <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Encrypted Uplink Sync Active</span>
                 </div>
                 <button onClick={() => { setIsSettingsOpen(false); localStorage.setItem('smarty_user_profile', JSON.stringify(profile)); }} className="px-8 py-4 sm:px-12 sm:py-6 bg-blue-600 rounded-2xl sm:rounded-[2.5rem] font-black uppercase tracking-[0.2em] text-[10px] sm:text-xs shadow-glow-blue active:scale-95 transition-all flex items-center justify-center gap-4 hover:bg-blue-500">
                   Synchronize Data <RefreshCw className="w-4 h-4" />
                 </button>
              </div>
           </div>
        </div>
      )}

      {isSidebarOpen && (
        <div className="fixed inset-y-0 right-0 w-full sm:w-[480px] glass-3d backdrop-blur-3xl border-l border-white/5 transition-transform duration-700 z-[200] flex flex-col shadow-3d-large animate-in slide-in-from-right duration-500">
          <div className="p-8 sm:p-10 border-b border-white/5 flex justify-between items-center">
            <h3 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-[0.2em]">History</h3>
            <button onClick={() => setIsSidebarOpen(false)} className="p-3 sm:p-4 glass-3d rounded-xl sm:rounded-2xl text-slate-500 hover:text-white transition-all"><X className="w-6 h-6 sm:w-7 sm:h-7"/></button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 sm:p-10 space-y-6 sm:space-y-8 custom-scrollbar">
            {history.map(item => (
              <div key={item.id} className="p-8 sm:p-10 glass-3d rounded-[2.5rem] sm:rounded-[3rem] group hover:bg-white/[0.04] transition-all cursor-pointer shadow-3d border-white/5 relative overflow-hidden" onClick={() => { setCurrentSession(item.messages); setIsSidebarOpen(false); }}>
                <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-all">
                  <button onClick={(e) => deleteHistoryItem(item.id, e)} className="p-3 glass-3d rounded-xl text-slate-600 hover:text-red-500 hover:bg-red-500/10 transition-all"><Trash className="w-4 h-4"/></button>
                </div>
                <p className="text-lg sm:text-xl font-black text-slate-200 line-clamp-2 pr-12 group-hover:text-blue-400 transition-colors uppercase tracking-tight">{item.title || 'Untitled Session'}</p>
                <div className="flex justify-between items-center mt-8">
                  <p className="text-[10px] sm:text-[11px] text-slate-600 font-mono uppercase tracking-widest">{new Date(item.timestamp).toLocaleDateString()}</p>
                  <div className="flex gap-4 items-center">
                    <span className="text-[9px] sm:text-[10px] font-black text-blue-500 uppercase flex items-center gap-2"><Activity className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> {item.duration || 0}s</span>
                    <PlayCircle className="w-7 h-7 sm:w-8 sm:h-8 text-slate-700 group-hover:text-blue-400 transition-all" />
                  </div>
                </div>
              </div>
            ))}
            {history.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center py-20 text-slate-700 opacity-40">
                <Database className="w-16 h-16 mb-6" />
                <p className="font-bold uppercase tracking-widest">No Neural Archives Found.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {showAdminAuth && (
        <div className="fixed inset-0 z-[600] bg-black/95 flex items-center justify-center p-6 sm:p-8 animate-in fade-in duration-500 backdrop-blur-2xl">
          <div className="w-full max-w-lg space-y-12 animate-3d-entrance text-center">
            <div className="w-24 h-24 sm:w-28 sm:h-28 bg-blue-600/10 border border-blue-500/20 rounded-[2.5rem] sm:rounded-[3.5rem] flex items-center justify-center mx-auto shadow-glow-blue">
              <Lock className="w-12 h-12 sm:w-14 sm:h-14 text-blue-500" />
            </div>
            <h3 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tighter">Nexus Override</h3>
            <div className="space-y-6 text-left">
              <div className="space-y-2">
                <label className="text-[9px] sm:text-[10px] font-black uppercase text-blue-500/60 ml-4 tracking-[0.2em]">Admin Identifier</label>
                <input type="text" value={adminIdInput} onChange={(e) => setAdminIdInput(e.target.value)} placeholder="Nexus-01" className="w-full bg-white/5 border border-white/10 rounded-2xl sm:rounded-3xl p-6 sm:p-7 text-white font-bold outline-none focus:border-blue-500 sm:text-lg shadow-inner" />
              </div>
              <div className="space-y-2">
                <label className="text-[9px] sm:text-[10px] font-black uppercase text-blue-500/60 ml-4 tracking-[0.2em]">Security Key</label>
                <input type="password" value={adminAuthInput} onChange={(e) => setAdminAuthInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAdminAuth()} placeholder="••••••••" className="w-full bg-white/5 border border-white/10 rounded-2xl sm:rounded-3xl p-6 sm:p-7 text-white font-bold outline-none focus:border-blue-500 sm:text-lg shadow-inner" />
              </div>
            </div>
            <div className="flex gap-4 sm:gap-6 pt-4">
              <button onClick={() => setShowAdminAuth(false)} className="flex-1 py-5 sm:py-7 glass-3d rounded-2xl sm:rounded-[2.5rem] font-black uppercase text-xs sm:text-sm tracking-widest hover:bg-white/5 transition-all">Abort</button>
              <button onClick={handleAdminAuth} className="flex-[2] py-5 sm:py-7 bg-blue-600 rounded-2xl sm:rounded-[2.5rem] font-black uppercase text-xs sm:text-sm tracking-widest shadow-glow-blue transition-all active:scale-95">Verify Identity</button>
            </div>
          </div>
        </div>
      )}

      {isAdminOpen && (
        <AdminDashboard 
          data={globalStore} 
          onClose={() => setIsAdminOpen(false)} 
          onClearLogs={() => { if(confirm("Terminate global matrix data?")) { const reset = { users: {}, logs: [], sessions: [] }; setGlobalStore(reset); localStorage.setItem('smarty_global_db', JSON.stringify(reset)); } }}
          onSaveStore={(u) => { setGlobalStore(u); localStorage.setItem('smarty_global_db', JSON.stringify(u)); }}
        />
      )}

      <style>{`
        @keyframes entrance-3d { from { transform: translateZ(-400px) rotateX(25deg); opacity: 0; } to { transform: translateZ(0) rotateX(0deg); opacity: 1; } }
        @keyframes msg-3d { from { transform: translateY(30px) translateZ(-80px); opacity: 0; } to { transform: translateY(0) translateZ(0); opacity: 1; } }
        .animate-3d-entrance { animation: entrance-3d 1.4s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
        .animate-3d-msg { animation: msg-3d 0.8s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
        .glass-3d { background: rgba(255, 255, 255, 0.04); backdrop-filter: blur(60px); border: 1px solid rgba(255, 255, 255, 0.12); }
        .shadow-3d { box-shadow: 0 45px 110px -25px rgba(0, 0, 0, 0.75), inset 0 1px 15px rgba(255, 255, 255, 0.08); }
        .shadow-3d-large { box-shadow: 0 120px 240px -50px rgba(0, 0, 0, 0.95), inset 0 1px 40px rgba(255, 255, 255, 0.04); }
        .glow-text { text-shadow: 0 0 30px rgba(255, 255, 255, 0.5); }
        .shadow-glow-blue { box-shadow: 0 0 50px rgba(59, 130, 246, 0.5); }
        .shadow-red-glow { box-shadow: 0 0 40px rgba(239, 68, 68, 0.4); }
        .mask-fade { mask-image: linear-gradient(to bottom, transparent, black 8%, black 92%, transparent); }
        .animate-spin-slow { animation: spin 24s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .perspective-1000 { perspective: 1000px; transform-style: preserve-3d; }
        .translate-z-[-200px] { transform: translateZ(-200px); }
        .translate-z-[20px] { transform: translateZ(20px); }
        .translate-z-[-10px] { transform: translateZ(-10px); }
        .translate-z-[50px] { transform: translateZ(50px); }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.08); border-radius: 10px; }
        
        input[type=range]::-webkit-slider-thumb {
          -webkit-appearance: none;
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #3b82f6;
          cursor: pointer;
          box-shadow: 0 0 15px rgba(59, 130, 246, 0.6);
          border: 4px solid #020617;
          margin-top: -10px;
        }
        input[type=range]::-webkit-slider-runnable-track {
          width: 100%;
          height: 4px;
          cursor: pointer;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
}
