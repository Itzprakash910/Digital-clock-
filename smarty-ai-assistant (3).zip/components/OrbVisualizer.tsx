
import React, { useEffect, useRef, useState } from 'react';

interface OrbVisualizerProps {
  isListening: boolean;
  isThinking: boolean;
  isActive: boolean;
  isTyping: boolean;
  audioLevel: number;
}

export default function OrbVisualizer({ isListening, isThinking, isActive, isTyping, audioLevel }: OrbVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 800 });

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const size = Math.min(window.innerWidth * 0.9, window.innerHeight * 0.6, 900);
        setDimensions({ width: size, height: size });
      }
    };
    window.addEventListener('resize', updateSize);
    updateSize();
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrame: number;
    let time = 0;

    const draw = () => {
      time += 0.02;
      const { width, height } = canvas;
      const centerX = width / 2;
      const centerY = height / 2;
      ctx.clearRect(0, 0, width, height);

      const baseRadius = width * 0.15;
      const pulse = isActive ? (audioLevel * width * 0.35) : 0;
      const currentRadius = baseRadius + pulse;

      // Volumetric Core Glow
      ctx.globalCompositeOperation = 'screen';
      for (let i = 0; i < 5; i++) {
        const glowRad = currentRadius * (2.5 + i * 1.5);
        const grad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, glowRad);
        let color = isThinking ? `rgba(168, 85, 247, ${0.2 / (i + 1)})` : `rgba(59, 130, 246, ${0.15 / (i + 1)})`;
        grad.addColorStop(0, color);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.arc(centerX, centerY, glowRad, 0, Math.PI * 2); ctx.fill();
      }

      // Organic 3D Neural Rings
      ctx.globalCompositeOperation = 'source-over';
      const rings = 8;
      for (let i = 0; i < rings; i++) {
        const ringRad = currentRadius * (1.2 + i * 0.4);
        const rotX = time * (0.1 + i * 0.03);
        const rotY = time * (0.15 + i * 0.02);
        
        ctx.strokeStyle = isThinking ? `rgba(192, 132, 252, ${0.4 / (i + 1)})` : `rgba(96, 165, 250, ${0.3 / (i + 1)})`;
        ctx.lineWidth = 1.5 - (i * 0.1);
        
        ctx.beginPath();
        for (let a = 0; a < Math.PI * 2; a += 0.1) {
          const x = Math.cos(a) * ringRad;
          const y = Math.sin(a) * ringRad * Math.cos(rotX + i);
          
          const finalX = centerX + (x * Math.cos(rotY) - y * Math.sin(rotY));
          const finalY = centerY + (x * Math.sin(rotY) + y * Math.cos(rotY));
          
          if (a === 0) ctx.moveTo(finalX, finalY);
          else ctx.lineTo(finalX, finalY);
        }
        ctx.closePath();
        ctx.stroke();

        // Pulsing Data Nodes on Rings
        if (isActive) {
          const dots = 4;
          for (let d = 0; d < dots; d++) {
            const angle = time * (2 + i * 0.5) + (d * Math.PI * 2 / dots);
            const dotX = centerX + Math.cos(angle) * ringRad;
            const dotY = centerY + Math.sin(angle) * ringRad * Math.cos(rotX + i);
            
            ctx.fillStyle = isThinking ? '#d8b4fe' : '#60a5fa';
            ctx.shadowBlur = 15; ctx.shadowColor = ctx.fillStyle;
            ctx.beginPath(); ctx.arc(dotX, dotY, 2.5 + Math.sin(time * 5) * 1, 0, Math.PI * 2); ctx.fill();
            ctx.shadowBlur = 0;
          }
        }
      }

      animationFrame = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animationFrame);
  }, [isActive, isListening, isThinking, audioLevel, dimensions]);

  return (
    <div ref={containerRef} className="relative flex items-center justify-center w-full aspect-square animate-float-slow transition-all duration-1000">
      <canvas ref={canvasRef} width={dimensions.width * 2} height={dimensions.height * 2} style={{ width: dimensions.width, height: dimensions.height }} className="z-10" />
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/5 glass shadow-3d-orb flex items-center justify-center transition-all duration-1000 
        ${isActive ? 'w-[20%] h-[20%] scale-110 border-blue-500/30' : 'w-[18%] h-[18%] scale-95 opacity-40'}`}>
        <div className={`w-[85%] h-[85%] rounded-full blur-3xl transition-all duration-1000 ${isThinking ? 'bg-purple-600/30' : 'bg-blue-600/30'} ${isActive ? 'opacity-100 animate-pulse' : 'opacity-0'}`}></div>
      </div>
      <style>{`
        @keyframes float-slow { 0%, 100% { transform: translateY(0) rotateX(2deg); } 50% { transform: translateY(-40px) rotateX(-2deg); } }
        .animate-float-slow { animation: float-slow 10s ease-in-out infinite; transform-style: preserve-3d; }
        .shadow-3d-orb { box-shadow: 0 0 100px rgba(59, 130, 246, 0.2), inset 0 0 50px rgba(255, 255, 255, 0.05); }
      `}</style>
    </div>
  );
};
