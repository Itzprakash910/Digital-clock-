
import React, { useState, useMemo } from 'react';
import { 
  Users, Activity, Database, X, Download, Trash2, 
  Clock, User, ShieldCheck, Search,
  TrendingUp, BarChart3, ArrowUpRight, Code, Copy, Check,
  Cpu, Zap, Radio, LayoutGrid, Terminal, Menu, AlertTriangle,
  History, Eye, ShieldOff, Ban, UserX, MessageSquare, AudioLines, Calendar, Gauge,
  ExternalLink, PlayCircle, Trophy, BarChart4, Filter,
  Square, CheckSquare, Trash, ChevronRight, Share2, Globe, UserCheck, RefreshCw, FileJson
} from 'lucide-react';
import { GlobalDataStore, ActivityLogEntry, UserProfile, ChatSession, UserPermissions } from '../types.ts';

interface AdminDashboardProps {
  onClose: () => void;
  data: GlobalDataStore;
  onClearLogs: () => void;
  onSaveStore: (store: GlobalDataStore) => void;
}

const SmartyLogo = ({ className = "w-10 h-10" }: { className?: string }) => (
  <div className={`${className} relative flex items-center justify-center`}>
    <svg viewBox="0 0 100 100" className="w-full h-full">
      <defs>
        <linearGradient id="adminLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60a5fa" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="45" fill="none" stroke="url(#adminLogoGrad)" strokeWidth="1" strokeDasharray="10 5" className="opacity-30" />
      <path d="M50 20 L30 50 L50 80 L70 50 Z" fill="none" stroke="url(#adminLogoGrad)" strokeWidth="2" />
      <rect x="42" y="42" width="16" height="16" rx="4" fill="url(#adminLogoGrad)" />
    </svg>
  </div>
);

export default function AdminDashboard({ onClose, data, onClearLogs, onSaveStore }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'logs' | 'vault'>('overview');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [adminMsg, setAdminMsg] = useState('');
  const [selectedNodeIds, setSelectedNodeIds] = useState<Set<string>>(new Set());
  const [isCopying, setIsCopying] = useState<string | null>(null);

  const stats = useMemo(() => {
    const usersList = Object.values(data.users || {});
    const totalUsers = usersList.length;
    const totalMessages = (data.logs || []).filter(l => l.action === 'MESSAGE_SENT').length;
    const onlineUsers = usersList.filter(u => u.isOnline && (Date.now() - u.lastSeen < 120000)).length;
    return { totalUsers, totalMessages, onlineUsers };
  }, [data]);

  const filteredUsers = useMemo(() => {
    return Object.entries(data.users || {}).filter(([id, u]) => 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) || id.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a, b) => b[1].lastSeen - a[1].lastSeen);
  }, [data.users, searchTerm]);

  const toggleNodeSelection = (id: string) => {
    const next = new Set(selectedNodeIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelectedNodeIds(next);
  };

  const bulkDeleteNodes = () => {
    if (selectedNodeIds.size === 0) return;
    if (confirm(`CRITICAL_OVERRIDE: Permanently delete ${selectedNodeIds.size} nodes?`)) {
      const updated = { ...data };
      selectedNodeIds.forEach(id => { delete updated.users[id]; });
      onSaveStore(updated);
      setSelectedNodeIds(new Set());
    }
  };

  const toggleBan = (userId: string) => {
    const user = data.users[userId];
    const isBanning = !user.permissions?.isBanned;
    if (confirm(`PROTOCOL_SYNC: ${isBanning ? 'Sever' : 'Restore'} uplink for node ${userId}?`)) {
      const updated = { ...data };
      updated.users[userId].permissions.isBanned = isBanning;
      updated.logs.unshift({
        id: 'log_' + Date.now(),
        timestamp: Date.now(),
        userName: 'Nexus Admin',
        action: isBanning ? 'USER_BANNED' : 'USER_UNBANNED',
        metadata: { targetUser: userId, text: `Node ${isBanning ? 'Banned' : 'Unbanned'} by Admin` }
      });
      onSaveStore(updated);
    }
  };

  const messageUser = (userId: string) => {
    if (!adminMsg.trim()) return;
    const updated = { ...data };
    updated.logs.unshift({ 
      id: 'msg_' + Date.now(), 
      timestamp: Date.now(), 
      userName: 'Nexus Admin', 
      action: 'ADMIN_MESSAGE', 
      metadata: { text: adminMsg, targetUser: userId } 
    });
    onSaveStore(updated);
    setAdminMsg('');
    alert("SIGNAL_INJECTED: Message delivered to node.");
  };

  const copyLogEntry = (log: ActivityLogEntry) => {
    const text = JSON.stringify(log, null, 2);
    navigator.clipboard.writeText(text);
    setIsCopying(log.id);
    setTimeout(() => setIsCopying(null), 1500);
  };

  const exportGlobalStore = () => {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus_vault_export_${new Date().toISOString()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-[600] bg-[#020512] text-white flex flex-col font-sans overflow-hidden perspective-2000 animate-in fade-in duration-500">
      <header className="h-20 sm:h-24 border-b border-white/5 flex items-center justify-between px-6 sm:px-10 bg-black/40 backdrop-blur-3xl shrink-0 z-50">
        <div className="flex items-center gap-4 sm:gap-8">
          <SmartyLogo className="w-10 h-10 sm:w-14 sm:h-14 shadow-blue-glow" />
          <div className="hidden xs:block">
            <h2 className="text-xl sm:text-3xl font-black uppercase tracking-tighter leading-none">Nexus <span className="text-blue-500">Admin</span></h2>
            <div className="flex items-center gap-3 mt-2">
               <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-glow-emerald"></div>
               <p className="text-[8px] sm:text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Protocol Oversight</p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 sm:gap-6">
           <div className="hidden lg:flex items-center gap-6 px-6 py-2 glass-3d rounded-2xl border-white/5">
              <div className="flex flex-col items-center border-r border-white/10 pr-6">
                 <span className="text-[8px] font-black uppercase text-slate-500">Sync Rate</span>
                 <span className="text-sm font-black text-blue-400">99.8%</span>
              </div>
              <div className="flex flex-col items-center">
                 <span className="text-[8px] font-black uppercase text-slate-500">Live Pulse</span>
                 <span className="text-sm font-black text-emerald-400">Stable</span>
              </div>
           </div>
           <button onClick={onClose} className="p-3 sm:p-5 glass-3d rounded-2xl hover:bg-red-600/10 hover:text-red-500 transition-all shadow-3d-small"><X className="w-5 h-5 sm:w-7 sm:h-7" /></button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden relative">
        <aside className="w-16 sm:w-80 border-r border-white/5 bg-black/20 p-2 sm:p-8 flex flex-col gap-6 sm:gap-12 shrink-0">
          <nav className="space-y-2 sm:space-y-4">
            {[
              { id: 'overview', icon: LayoutGrid, label: 'Telemetry' },
              { id: 'users', icon: Users, label: 'Node Map' },
              { id: 'logs', icon: Terminal, label: 'Signals' },
              { id: 'vault', icon: Database, label: 'The Vault' }
            ].map(item => (
              <button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`w-full flex items-center justify-center sm:justify-start gap-0 sm:gap-6 p-4 sm:p-6 rounded-2xl transition-all group ${activeTab === item.id ? 'bg-blue-600 shadow-blue-glow text-white' : 'hover:bg-white/5 text-slate-500'}`}>
                <item.icon className={`w-6 h-6 shrink-0 ${activeTab === item.id ? 'text-white' : 'group-hover:text-blue-400'}`} />
                <span className="hidden sm:block text-[10px] font-black uppercase tracking-[0.2em]">{item.label}</span>
              </button>
            ))}
          </nav>
          
          <div className="mt-auto space-y-4">
             <div className="hidden sm:block p-6 glass-3d rounded-[2rem] space-y-4">
                <div className="flex justify-between items-center text-[9px] font-black uppercase text-slate-500">
                   <span>Pulse</span>
                   <span className="text-emerald-500">{stats.onlineUsers} Nodes</span>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-blue-500 animate-pulse" style={{ width: `${Math.min(100, (stats.onlineUsers/10)*100)}%` }}></div>
                </div>
             </div>
             <button onClick={onClearLogs} className="w-full py-4 rounded-xl border border-red-500/20 text-red-500 text-[10px] font-black uppercase hover:bg-red-500/10 transition-all flex items-center justify-center gap-2"><Trash2 className="w-4 h-4"/><span className="hidden sm:inline">Purge logs</span></button>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto p-4 sm:p-12 custom-scrollbar perspective-2000">
          <div className="max-w-6xl mx-auto space-y-12 animate-3d-entrance">
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-10">
                <div className="p-8 glass-3d rounded-[3rem] shadow-3d-large bg-gradient-to-br from-blue-600/5 to-transparent border-blue-500/10">
                  <div className="w-12 h-12 bg-blue-600/10 rounded-2xl flex items-center justify-center mb-6 border border-blue-500/20"><Users className="text-blue-400 w-6 h-6" /></div>
                  <p className="text-4xl sm:text-5xl font-black text-white tracking-tighter mb-2">{stats.totalUsers}</p>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Active Identifiers</p>
                </div>
                <div className="p-8 glass-3d rounded-[3rem] shadow-3d-large bg-gradient-to-br from-purple-600/5 to-transparent border-purple-500/10">
                  <div className="w-12 h-12 bg-purple-600/10 rounded-2xl flex items-center justify-center mb-6 border border-purple-500/20"><Radio className="text-purple-400 w-6 h-6" /></div>
                  <p className="text-4xl sm:text-5xl font-black text-white tracking-tighter mb-2">{stats.totalMessages}</p>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Transmissions</p>
                </div>
                <div className="p-8 glass-3d rounded-[3rem] shadow-3d-large bg-gradient-to-br from-emerald-600/5 to-transparent border-emerald-500/10">
                  <div className="w-12 h-12 bg-emerald-600/10 rounded-2xl flex items-center justify-center mb-6 border border-emerald-500/20"><Zap className="text-emerald-400 w-6 h-6" /></div>
                  <p className="text-4xl sm:text-5xl font-black text-white tracking-tighter mb-2">{stats.onlineUsers}</p>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Uplinks</p>
                </div>
                
                <div className="col-span-full p-8 sm:p-10 glass-3d rounded-[3.5rem] shadow-3d-large relative overflow-hidden">
                   <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
                      <div>
                         <h3 className="text-2xl font-black uppercase tracking-tighter">Cluster Traffic</h3>
                         <p className="text-[10px] text-slate-500 font-black uppercase mt-2">Neural activity across global nodes</p>
                      </div>
                      <div className="flex gap-2">
                        <div className="px-4 py-2 bg-blue-500/10 text-blue-400 text-[8px] font-black uppercase rounded-lg border border-blue-500/20">LIVE_DATA</div>
                      </div>
                   </div>
                   <div className="h-48 sm:h-64 flex items-end gap-1 px-1 border-b border-white/5 pb-2">
                     {[...Array(window.innerWidth < 640 ? 20 : 40)].map((_, i) => (
                       <div key={i} className="flex-1 bg-gradient-to-t from-blue-600/20 to-blue-500/60 rounded-t-md hover:from-blue-400 transition-all cursor-crosshair group relative" style={{ height: `${15 + Math.random() * 85}%` }}>
                          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-blue-600 text-[8px] px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">SEG_{i}</div>
                       </div>
                     ))}
                   </div>
                </div>
              </div>
            )}

            {activeTab === 'users' && !selectedUserId && (
              <div className="space-y-10">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div>
                    <h3 className="text-3xl font-black uppercase tracking-tighter">Node Registry</h3>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest mt-2">Authenticated User Network</p>
                  </div>
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    <div className="relative flex-1">
                      <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Filter nodes..." className="bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-6 text-sm font-bold w-full md:w-72 focus:border-blue-500 outline-none transition-all shadow-inner" />
                    </div>
                    {selectedNodeIds.size > 0 && (
                      <button onClick={bulkDeleteNodes} className="p-4 bg-red-600 rounded-2xl text-white shadow-glow-red hover:scale-110 active:scale-95 transition-all">
                        <Trash className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredUsers.map(([id, user]) => (
                    <div key={id} onClick={() => setSelectedUserId(id)} className={`p-8 glass-3d rounded-[3rem] shadow-3d-large border-t-2 transition-all relative overflow-hidden group cursor-pointer ${selectedNodeIds.has(id) ? 'border-blue-500 bg-blue-500/5' : user.permissions?.isBanned ? 'border-red-500/50 grayscale-[0.5]' : 'border-white/5 hover:border-white/10'}`}>
                      <div className="absolute top-6 right-6 z-20">
                         <button onClick={(e) => { e.stopPropagation(); toggleNodeSelection(id); }} className={`p-2 rounded-lg border transition-all ${selectedNodeIds.has(id) ? 'bg-blue-600 text-white border-blue-400' : 'glass-3d text-slate-700 border-white/5'}`}>
                            {selectedNodeIds.has(id) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                         </button>
                      </div>
                      
                      <div className="flex flex-col items-center text-center">
                         <div className="relative mb-6">
                            <img src={user.avatar || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop'} className="w-20 h-20 rounded-[2rem] object-cover shadow-2xl border-2 border-white/5" />
                            <div className={`absolute -bottom-2 -right-2 w-7 h-7 rounded-xl border-4 border-[#020512] flex items-center justify-center ${user.isOnline ? 'bg-emerald-500' : 'bg-slate-700'}`}>
                               {user.isOnline ? <Zap className="w-3 h-3 text-white" /> : <Clock className="w-3 h-3 text-white" />}
                            </div>
                         </div>
                         <h4 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-2">
                           {user.name}
                           {user.permissions?.isBanned && <Ban className="w-4 h-4 text-red-500" />}
                         </h4>
                         <p className="text-[9px] text-slate-500 font-mono mt-2 uppercase">Node_ID: {id.slice(0, 8)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {selectedUserId && data.users[selectedUserId] && (
              <div className="space-y-12 animate-3d-entrance">
                <button onClick={() => setSelectedUserId(null)} className="text-[10px] font-black uppercase text-slate-500 flex items-center gap-3 hover:text-white transition-all"><ChevronRight className="w-4 h-4 rotate-180" /> Return to Cluster Registry</button>
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                   <div className="lg:col-span-4 p-10 glass-3d rounded-[3.5rem] sm:rounded-[4rem] text-center shadow-3d-large">
                      <div className="relative mb-10 inline-block">
                         <img src={data.users[selectedUserId].avatar || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=100&h=100&fit=crop'} className="w-40 h-40 sm:w-48 sm:h-48 rounded-[3.5rem] object-cover shadow-blue-glow border-4 border-white/5" />
                         <div className={`absolute -bottom-4 -right-4 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-4 border-[#020512] flex items-center justify-center ${data.users[selectedUserId].isOnline ? 'bg-emerald-500' : 'bg-slate-700'}`}>
                           <Activity className={`w-6 h-6 sm:w-7 sm:h-7 text-white ${data.users[selectedUserId].isOnline ? 'animate-pulse' : ''}`} />
                         </div>
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tighter mb-4">{data.users[selectedUserId].name}</h3>
                      <div className="flex flex-wrap justify-center gap-2 mb-8">
                        <span className={`px-4 py-1.5 rounded-lg text-[8px] font-black uppercase tracking-widest border ${data.users[selectedUserId].permissions?.isBanned ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'}`}>
                          {data.users[selectedUserId].permissions?.isBanned ? 'Node_Offline' : 'Uplink_Sync'}
                        </span>
                      </div>
                      
                      <div className="space-y-3">
                        <button onClick={() => toggleBan(selectedUserId)} className={`w-full p-5 rounded-2xl text-[10px] font-black uppercase flex items-center justify-center gap-3 transition-all ${data.users[selectedUserId].permissions?.isBanned ? 'bg-emerald-600/10 text-emerald-400 hover:bg-emerald-600/20' : 'bg-red-600/10 text-red-500 hover:bg-red-600/20'}`}>
                           {data.users[selectedUserId].permissions?.isBanned ? <RefreshCw className="w-4 h-4"/> : <ShieldOff className="w-4 h-4"/>}
                           {data.users[selectedUserId].permissions?.isBanned ? 'Restore Connectivity' : 'Sever Neural Link'}
                        </button>
                      </div>
                   </div>
                   
                   <div className="lg:col-span-8 space-y-10">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                         {[
                           { label: 'Uplink Est.', val: new Date(data.users[selectedUserId].created).toLocaleDateString(), icon: Calendar },
                           { label: 'Last Signal', val: new Date(data.users[selectedUserId].lastSeen).toLocaleTimeString(), icon: History },
                           { label: 'Total Sync', val: `${Math.round(data.users[selectedUserId].stats?.totalVoiceMinutes || 0)} min`, icon: Clock }
                         ].map((item, i) => (
                           <div key={i} className="p-8 glass-3d rounded-[2.5rem] shadow-3d-small flex flex-col items-center sm:items-start">
                              <item.icon className="w-5 h-5 text-slate-500 mb-4" />
                              <p className="text-lg font-black text-white">{item.val}</p>
                              <p className="text-[9px] text-slate-600 font-black uppercase mt-1 tracking-widest">{item.label}</p>
                           </div>
                         ))}
                      </div>

                      <div className="p-8 sm:p-10 glass-3d rounded-[3rem] shadow-3d-large bg-gradient-to-br from-red-600/[0.03] to-transparent">
                         <div className="flex justify-between items-center mb-8">
                            <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-red-500 flex items-center gap-3"><MessageSquare className="w-5 h-5" /> Protocol Override Message</h4>
                         </div>
                         <div className="flex flex-col sm:flex-row gap-4">
                            <input value={adminMsg} onChange={(e) => setAdminMsg(e.target.value)} placeholder="Enter command message for node..." className="flex-1 bg-black/20 border border-white/5 rounded-2xl px-6 py-5 text-sm font-bold outline-none focus:border-red-500/50 shadow-inner" />
                            <button onClick={() => messageUser(selectedUserId)} className="px-10 py-5 bg-red-600 hover:bg-red-700 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-glow-red transition-all">Inject Signal</button>
                         </div>
                      </div>
                   </div>
                </div>
              </div>
            )}

            {activeTab === 'logs' && (
              <div className="space-y-8 pb-20">
                 <div className="flex justify-between items-center">
                    <h3 className="text-3xl font-black uppercase tracking-tighter">Signal Stream</h3>
                 </div>
                 <div className="space-y-4">
                   {data.logs.slice(0, 100).map(log => (
                     <div key={log.id} className="p-6 sm:p-8 glass-3d rounded-[2rem] flex flex-col lg:flex-row lg:items-center gap-6 group hover:border-blue-500/30 transition-all">
                       <div className="text-slate-600 font-mono text-[9px] w-48 uppercase shrink-0">{new Date(log.timestamp).toLocaleString()}</div>
                       <div className="flex-1 flex items-center gap-6 overflow-hidden">
                         <div className="flex items-center gap-4 min-w-[150px] shrink-0">
                           <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center border border-white/10 group-hover:border-blue-500/20"><User className="w-4 h-4 text-slate-500"/></div>
                           <span className="text-white font-black uppercase text-[10px] tracking-widest truncate">{log.userName}</span>
                         </div>
                         <div className="px-4 py-1.5 bg-blue-600/10 rounded-lg border border-blue-500/10 text-[8px] font-black uppercase text-blue-400 shrink-0">{log.action}</div>
                         <p className="flex-1 text-slate-400 font-bold italic opacity-60 truncate text-xs sm:text-sm">{log.metadata?.text || 'Standard pulse protocol signature.'}</p>
                       </div>
                       <button onClick={() => copyLogEntry(log)} className={`p-4 glass-3d rounded-xl transition-all ${isCopying === log.id ? 'text-emerald-500 scale-110' : 'text-slate-500 hover:text-white'}`}>
                          {isCopying === log.id ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                       </button>
                     </div>
                   ))}
                 </div>
              </div>
            )}

            {activeTab === 'vault' && (
              <div className="space-y-12 animate-3d-entrance">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-8">
                  <h3 className="text-4xl font-black uppercase tracking-tighter">Nexus Vault</h3>
                  <button onClick={exportGlobalStore} className="flex items-center gap-4 px-10 py-5 bg-emerald-600 hover:bg-emerald-500 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-glow-emerald transition-all">
                    <Download className="w-5 h-5" /> Export Data Vault
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                   <div className="p-10 glass-3d rounded-[3rem] sm:rounded-[4rem] shadow-3d-large space-y-6 overflow-hidden">
                      <div className="bg-black/40 rounded-[2rem] p-6 font-mono text-[9px] text-slate-500 h-96 overflow-y-auto border border-white/5 custom-scrollbar leading-relaxed">
                         <pre>{JSON.stringify(data, null, 2)}</pre>
                      </div>
                   </div>
                   <div className="flex flex-col items-center justify-center p-10 glass-3d rounded-[3rem] sm:rounded-[4rem] border-red-500/20 bg-red-500/5 text-center space-y-8">
                      <AlertTriangle className="w-16 h-16 text-red-500" />
                      <h4 className="text-2xl font-black uppercase">Dangerous Overrides</h4>
                      <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest leading-relaxed">Purging the vault severs all history records permanently.</p>
                      <button onClick={onClearLogs} className="px-10 py-5 border border-red-500/20 text-red-500 hover:bg-red-500/10 rounded-2xl font-black uppercase text-xs tracking-widest">Hard Purge Registry</button>
                   </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      <style>{`
        .glass-3d { background: rgba(255, 255, 255, 0.02); backdrop-filter: blur(50px); border: 1px solid rgba(255, 255, 255, 0.08); }
        .shadow-3d-small { box-shadow: 0 10px 40px -10px rgba(0,0,0,0.5), inset 0 1px 10px rgba(255,255,255,0.02); }
        .shadow-3d-large { box-shadow: 0 100px 200px -60px rgba(0,0,0,0.85), inset 0 1px 40px rgba(255,255,255,0.03); }
        .shadow-blue-glow { box-shadow: 0 0 50px rgba(59, 130, 246, 0.3); }
        .shadow-glow-emerald { box-shadow: 0 0 40px rgba(16, 185, 129, 0.3); }
        .shadow-glow-red { box-shadow: 0 0 40px rgba(239, 68, 68, 0.3); }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.08); border-radius: 10px; }
        @keyframes entrance-3d { from { transform: translateZ(-300px) translateY(20px); opacity: 0; } to { transform: translateZ(0) translateY(0); opacity: 1; } }
        .animate-3d-entrance { animation: entrance-3d 1s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
      `}</style>
    </div>
  );
}
