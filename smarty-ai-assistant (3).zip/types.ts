
export interface AudioConfig {
  sampleRate: number;
  channels: number;
}

export enum SessionStatus {
  IDLE = 'IDLE',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  ERROR = 'ERROR'
}

export interface TranscriptionEntry {
  role: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: number;
  modelUsed?: string;
  isVoice?: boolean;
  groundingChunks?: any[];
}

export interface ChatSession {
  id: string;
  title: string;
  messages: TranscriptionEntry[];
  timestamp: number;
  duration?: number; // in seconds
  modelUsed?: string;
}

export type VoiceName = 'Zephyr' | 'Puck' | 'Charon' | 'Kore' | 'Fenrir';

export interface VoiceSettings {
  voiceName: VoiceName;
  speechRate: number;
  isTranslationEnabled: boolean;
  targetLanguage: string;
}

export interface UserPermissions {
  canUseVoice: boolean;
  canUseVision: boolean;
  canUseSearch: boolean;
  isBanned: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string; 
  setupComplete: boolean;
  storageConsent: boolean;
  permissions: UserPermissions;
  stats?: {
    totalMessages: number;
    totalVoiceMinutes: number;
    lastActive: number;
    modelsUsed?: string[];
  };
}

export interface ActivityLogEntry {
  id: string;
  timestamp: number;
  userName: string;
  action: 'SETUP_COMPLETE' | 'MESSAGE_SENT' | 'VOICE_START' | 'PROFILE_EDIT' | 'SESSION_SAVED' | 'SYSTEM_ACCESS' | 'USER_BANNED' | 'ADMIN_MESSAGE' | 'USER_UNBANNED' | 'SESSION_DELETED';
  metadata?: {
    text?: string;
    sessionId?: string;
    userAgent?: string;
    platform?: string;
    language?: string;
    model?: string;
    duration?: number;
    targetUser?: string;
    [key: string]: any;
  };
}

export interface GlobalDataStore {
  users: Record<string, UserProfile & { lastSeen: number; created: number; isOnline: boolean }>;
  logs: ActivityLogEntry[];
  sessions: ChatSession[];
}
